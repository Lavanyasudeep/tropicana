@if(!$confirmed)
    <div class="qr-code">
        {!! $qrCode !!}
    </div>
    <p>Scan this QR code with your authenticator app</p>
@endif