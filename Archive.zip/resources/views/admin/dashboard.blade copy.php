@extends('adminlte::page')

@section('title', 'Dashboard')

@section('content_header')
    <h1>Dashboard</h1>
@stop

@section('content')
    <div class="dashboard-main-panel" >
        <div class="card" >
            <div class="card-body" >
                <p>Welcome to your Cold Storage.</p>
            </div>
        </div>
    </div>
@stop
