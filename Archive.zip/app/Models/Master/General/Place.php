<?php

namespace App\Models\Master\General;

use Illuminate\Database\Eloquent\Model;

class Place extends Model
{
    protected $table = 'cs_place';
    protected $guarded = [];
}
