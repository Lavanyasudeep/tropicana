<?php

namespace App\Http\Controllers\Admin\Master\Inventory;

use App\Models\Master\Purchase\Supplier;
use App\Models\Master\Sales\Customer;
use App\Models\Master\Inventory\Product;
use App\Models\Master\Inventory\ProductCategory;
use App\Models\Master\Inventory\ProductMaster;
use App\Models\Master\Inventory\ProductAttribute;
use App\Models\Master\General\Unit;
use App\Models\Master\General\Brand;
use App\Models\Master\General\Tax;

use App\Http\Requests\Master\Inventory\ProductRequest;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

use DataTables;

class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $categories = ProductCategory::select('product_category_id', 'product_category_name')->orderBy('product_category_name')->limit(100)->get();
        $brands = Brand::select('brand_id', 'brand_name')->get();
        $customers = Customer::select('customer_id', 'customer_name')->get();

        if ($request->ajax()) {
            $query = ProductMaster::query();
            return DataTables::of($query)
                ->addColumn('actions', function ($row) {
                    $editUrl = route('admin.master.inventory.product.edit', $row->product_master_id);
                    $deleteUrl = route('admin.master.inventory.product.destroy', $row->product_master_id);

                    return '
                        <a href="javascript:void(0);" onclick="editAttribute(' . $row->product_master_id . ')" class="btn btn-sm btn-warning"><i class="fas fa-edit"></i></a>
                        <form action="' . $deleteUrl . '" method="POST" style="display:inline-block;">
                            ' . csrf_field() . method_field('DELETE') . '
                            <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm(\'Are you sure?\')"><i class="fas fa-trash"></i></button>
                        </form>';
                })
                ->rawColumns(['actions'])
                ->make(true);
        }

        return view('admin.master.inventory.product.index', compact('categories', 'brands', 'customers'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $categories = ProductCategory::select('product_category_id', 'product_category_name')->orderBy('product_category_name')->limit(100)->get();
        $brands = Brand::select('brand_id', 'brand_name')->get();
        $units = Unit::select('unit_id', 'conversion_unit')->get();
        $suppliers = Supplier::select('supplier_id', 'supplier_name')->get();
        $customers = Customer::select('customer_id', 'customer_name')->get();
        $attributes = ProductAttribute::get();
        $taxes = Tax::select('tax_id', 'tax_per')->get();

        return view('admin.master.inventory.product.form', compact('categories','brands','units','suppliers','taxes', 'customers','attributes'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(ProductAttributeRequest $request)
    {
        DB::beginTransaction();

        try {
            $attribute = ProductAttribute::create($request->validated());

            DB::commit();

            if($request->ajax()) {
                return response()->json([
                    'message' => 'Attribute created successfully',
                    'data' => $attribute,
                ]);
            } else {
                return redirect()->back()->with('success', 'Attribute created successfully.');
            }

        } catch (\Exception $e) {
            DB::rollBack();
            return back()->withErrors([
                'error' => 'Failed to create attribute',
                'details' => $e->getMessage()
            ])->withInput();
        }
        
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $attribute = ProductAttribute::findOrFail($id);
        return response()->json($attribute);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(ProductAttributeRequest $request, string $id)
    {
        DB::beginTransaction();

        try {
            $attribute = ProductAttribute::findOrFail($id);
            $attribute->update($request->validated());

            DB::commit();

            return redirect()->back()->with('success', 'Attribute updated successfully.');
        } catch (\Exception $e) {
            DB::rollBack();
            return back()->withErrors([
                'error' => 'Failed to create attribute',
                'details' => $e->getMessage()
            ])->withInput();
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $attribute = ProductAttribute::findOrFail($id);
        $attribute->delete();

        return redirect()->back()->with('success', 'Attribute deleted successfully.');
    }

    public function inputField($id, Request $request)
    {
        $attribute = ProductAttribute::findOrFail($id);

        // Generate the input field based on data type
        $inputHtml = match ($attribute->data_type) {
            'text' => "<input type=\"text\" name=\"products[{$request->product_index}][specifications][{$request->row_index}][value]\" class=\"form-control form-control-sm spec-value-input\" required>",
            'number' => "<input type=\"number\" name=\"products[{$request->product_index}][specifications][{$request->row_index}][value]\" class=\"form-control form-control-sm spec-value-input\" required>",
            'color' => "<input type=\"color\" name=\"products[{$request->product_index}][specifications][{$request->row_index}][value]\" class=\"form-control form-control-sm spec-value-input\" required>",
            'boolean' => "<select class=\"form-control form-control-sm spec-value-input\" name=\"products[{$request->product_index}][specifications][{$request->row_index}][value]\" required>
                            <option value=\"1\">Yes</option>
                            <option value=\"0\">No</option>
                        </select>",
            'date' => "<input type=\"date\" class=\"form-control form-control-sm spec-value-input\" name=\"products[{$request->product_index}][specifications][{$request->row_index}][value]\" required>",
            default => "<input type=\"text\" class=\"form-control form-control-sm spec-value-input\" name=\"products[{$request->product_index}][specifications][{$request->row_index}][value]\" required>",
        };

        return response()->json(['input' => $inputHtml]);
    }

}
